# Test Plan Identifier to run specific Tests
jmeterTestPlanName2 = post_api_1_1

# Note: Keep "none" if any of the Tests need not to run

# Test Plan Identifier to run all Tests
jmeterTestPlanName1 = *

# To open JMeter GUI
mvn jmeter:configure jmeter:gui

# New Maven Command for Jenkins
mvn clean verify -DerrorRateThresholdPercentage='${ErrorThresholdPercentage}' -DServerNameOrHost='${ServerNameOrHost}' -DjmeterTestPlanName1='${jmeterTestPlanName1}' -DjmeterTestPlanName2='${jmeterTestPlanName2}' -DPath_1_1='${Path_1_1}' -DThinkTimeRequired='${thinkTimeRequired}' -DThinkTimeInMilliSec='${thinkTimeInMilliSec}' -DtotalThreadCount_1_1='${TotalThreadCount_1_1}' -DinitialDelayInSec_1_1='${InitialDelayInSec_1_1}' -DstartUpTimeInSec_1_1='${RampUpTimeInSec_1_1}' -DholdLoadInSec_1_1='${HoldLoadDurationInSec_1_1}' -DshutdownTimeInSec_1_1='${ShutdownTimeInSec_1_1}'  -DDurationAssertionInMilliSec_1_1='${durationAssertionInMilliSec_1_1}' 

# New Maven Command for Local to run specific test
mvn clean verify -DerrorRateThresholdPercentage=10 -DServerNameOrHost=rcp-services-stage-gateway.rcprakuten.com -DjmeterTestPlanName1=none -DjmeterTestPlanName2=post_api_1_1 -DPath_1_1=/gw/partners/18/transform-product -DThinkTimeRequired=true -DThinkTimeInMilliSec=100 -DtotalThreadCount_1_1=10 -DinitialDelayInSec_1_1=0 -DstartUpTimeInSec_1_1=10 -DholdLoadInSec_1_1=20 -DshutdownTimeInSec_1_1=10  -DDurationAssertionInMilliSec_1_1=5000 

# New Maven Command for Local to run all test
mvn clean verify -DerrorRateThresholdPercentage=10 -DServerNameOrHost=rcp-services-stage-gateway.rcprakuten.com -DjmeterTestPlanName1=* -DjmeterTestPlanName2=none -DPath_1_1=/gw/partners/18/transform-product -DThinkTimeRequired=true -DThinkTimeInMilliSec=100 -DtotalThreadCount_1_1=10 -DinitialDelayInSec_1_1=0 -DstartUpTimeInSec_1_1=10 -DholdLoadInSec_1_1=20 -DshutdownTimeInSec_1_1=10  -DDurationAssertionInMilliSec_1_1=5000 



