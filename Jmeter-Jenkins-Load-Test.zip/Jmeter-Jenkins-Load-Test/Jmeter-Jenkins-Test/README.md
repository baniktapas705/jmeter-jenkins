# Test Plan Identifier to run specific Tests
jmeterTestPlanName2 = post_api_1_1

# Note: Keep "none" if any of the Tests need not to run

# Test Plan Identifier to run all Tests
jmeterTestPlanName1 = *

# To open JMeter GUI
mvn jmeter:configure jmeter:gui

# New Maven Command for Jenkins
mvn clean verify -DerrorRateThresholdPercentage='${ErrorThresholdPercentage}' -DserverNameOrHost='${ServerNameOrHost}' -DjmeterTestPlanName1='${jmeterTestPlanName1}' -DjmeterTestPlanName2='${jmeterTestPlanName2}' -DPath_1_1='${Path_1_1}' -DThinkTimeRequired='${thinkTimeRequired}' -DThinkTimeInMilliSec='${thinkTimeInMilliSec}' -DtotalThreadCount_1_1='${TotalThreadCount_1_1}' -DinitialDelayInSec_1_1='${InitialDelayInSec_1_1}' -DstartUpTimeInSec_1_1='${RampUpTimeInSec_1_1}' -DholdLoadInSec_1_1='${HoldLoadDurationInSec_1_1}' -DshutdownTimeInSec_1_1='${ShutdownTimeInSec_1_1}'  -DDurationAssertionInMilliSec_1_1='${durationAssertionInMilliSec_1_1}' 

# New Maven Command for Local to run specific test
mvn clean verify -DerrorRateThresholdPercentage=10 -DserverNameOrHost=petstore.swagger.io -DjmeterTestPlanName1=none -DjmeterTestPlanName2=post_api_1_1 -Dpath_1_1=/v2/pet -DThinkTimeRequired=true -DThinkTimeInMilliSec=100 -DtotalThreadCount_1_1=10 -DinitialDelayInSec_1_1=0 -DstartUpTimeInSec_1_1=10 -DholdLoadInSec_1_1=20 -DshutdownTimeInSec_1_1=10  -DDurationAssertionInMilliSec_1_1=5000 

# New Maven Command for Local to run all test
mvn clean verify -DerrorRateThresholdPercentage=10 -DserverNameOrHost=petstore.swagger.io -DjmeterTestPlanName1=* -DjmeterTestPlanName2=none -Dpath_1_1=/v2/pet -DThinkTimeRequired=true -DThinkTimeInMilliSec=100 -DtotalThreadCount_1_1=10 -DinitialDelayInSec_1_1=0 -DstartUpTimeInSec_1_1=10 -DholdLoadInSec_1_1=20 -DshutdownTimeInSec_1_1=10  -DDurationAssertionInMilliSec_1_1=5000 

# Pro Tips
Maven parameters are defined in pom.xml properties section
```
<properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <!--Start : Test Parameter Default Values which can be updated from mvn command or Jenkins UI based build parameters   -->
        <!-- Parameterize this part according to your Test Plan (JMX File)-->
        <totalThreadCount_1_1>2</totalThreadCount_1_1>
        <initialDelayInSec_1_1>0</initialDelayInSec_1_1>
        <startUpTimeInSec_1_1>0</startUpTimeInSec_1_1>
        <holdLoadInSec_1_1>2</holdLoadInSec_1_1>
        <shutdownTimeInSec_1_1>0</shutdownTimeInSec_1_1>
        <DurationAssertionInMilliSec_1_1>5000</DurationAssertionInMilliSec_1_1>
        <!--        Below Field will set the Build Failure Criteria, if total number of error % is => 10 then build will be failed-->
        <errorRateThresholdPercentage>20</errorRateThresholdPercentage>
        <!--        Below Field will set the Test Plan Name to execute, if set as * then all test plans will execute-->
        <jmeterTestPlanName1>none</jmeterTestPlanName1>
        <jmeterTestPlanName2>post_api_1_1</jmeterTestPlanName2>
        <!--        Think Time Required or not in the Tests-->
        <ThinkTimeRequired>false</ThinkTimeRequired>
        <!--        If above field is set to true, then below fields will be considered and each thread will wait for certain time before it requests again-->
        <ThinkTimeInMilliSec>5000</ThinkTimeInMilliSec>
        <!--End : Test Parameter Default Values which can be updated from mvn command or Jenkins UI based build parameters   -->
        
        <!-- **Replace the below values with your serverNameOrHost and path_1_1** -->
        <serverNameOrHost>petstore.swagger.io</serverNameOrHost>
        <path_1_1>/v2/pet</path_1_1>
        
    </properties>

```

Jenkins File Parameters are defined in Jenkins UI


**Maven commands running in Jenkins Pipeline**
```
mvn clean verify -DerrorRateThresholdPercentage='${ErrorThresholdPercentage}' -DserverNameOrHost='${ServerNameOrHost}' -DjmeterTestPlanName1='${jmeterTestPlanName1}' -DjmeterTestPlanName2='${jmeterTestPlanName2}' -Dpath_1_1='${Path_1_1}' -DThinkTimeRequired='${thinkTimeRequired}' -DThinkTimeInMilliSec='${thinkTimeInMilliSec}' -DtotalThreadCount_1_1='${TotalThreadCount_1_1}' -DinitialDelayInSec_1_1='${InitialDelayInSec_1_1}' -DstartUpTimeInSec_1_1='${RampUpTimeInSec_1_1}' -DholdLoadInSec_1_1='${HoldLoadDurationInSec_1_1}' -DshutdownTimeInSec_1_1='${ShutdownTimeInSec_1_1}'  -DDurationAssertionInMilliSec_1_1='${durationAssertionInMilliSec_1_1}'
```
Here in the left side of the above command, we are passing the parameters from Test Plan to the Maven Command. These parameters are defined in the pom.xml file. Values are passed from Jenkins UI to the Maven Command. Right side of the above command, we are passing the values from Jenkins UI parameters to the Maven Command. These values are defined in Jenkins UI or default values set in Jenkins file.

